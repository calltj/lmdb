const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();
const URI = process.env.MONGODB_URI || "mongodb://localhost:27017/driverhub";
mongoose.connect(URI, { useNewUrlParser: true, useUnifiedTopology: true });

const app = express();
app.use(express.json());

// Sample schema and one route for demonstration (full code will have 50 endpoints)
const driverSchema = new mongoose.Schema({ driverId:String, name:String });
const Driver = mongoose.model("Driver", driverSchema);

app.post("/drivers", async (req, res) => res.status(201).json(await new Driver(req.body).save()));
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(`driverhub running on port ${PORT}`));